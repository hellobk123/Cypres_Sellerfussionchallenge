describe("Verify Product API call", () => {
  before(() => {
    cy.intercept("/api/products").as("allProducts");
  });

  it("Product API call should occur and save the response to fixture file", () => {
    cy.visit("/");
    cy.wait("@allProducts")
      .its("response.body")
      .then((res) => {
        cy.writeFile("cypress/fixtures/products.json", res);
        cy.log(res);
      });
  });
});
