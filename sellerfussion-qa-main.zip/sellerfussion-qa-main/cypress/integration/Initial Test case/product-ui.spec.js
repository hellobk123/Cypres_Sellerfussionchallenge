import productArray from "../../fixtures/products.json";
const { softExpect } = chai;

let totalFullfilled;
let totalunFullfilled;

describe("Verify total fullfilled quantity for each product", () => {
  before(() => {
    cy.visit("/");
  });

  productArray.data.forEach((product, index) => {
    it(`Verify total fullfilled quantity for: ${product.asin}`, function () {
      totalFullfilled =
        product.fulfillable +
        product.transfer +
        product.inbound_receiving +
        product.inbound_shipped +
        product.inbound_working +
        product.total_unfulfillable +
        product.total_researching;

      cy.xpath(`(//tbody/tr/td[5]/div[1]//span)[${index + 1}]`).should('be.visible').click();
      cy.xpath("((//p[text()='Amazon Fulfilled Quantity']/../div//span[text()='Total'])[1]/../../following-sibling::div)[1]//b").should('be.visible').invoke('text').then(total => {
        total = total.replace(/[^0-9a-zA-Z. ]/g, '');
        softExpect(+total).to.equal(totalFullfilled);
      });
      cy.xpath(`(//tbody/tr/td[2])[${index + 1}]`).click({ force: true });
    });
  });

});

describe("Verify total unfullfilled quantity for each product", () => {
  before(() => {
    cy.visit("/");
  });

  productArray.data.forEach((product, index) => {
    it(`Verify total unfullfilled quantity for: ${product.asin}`, function () {
      totalunFullfilled = product.customer_damaged + product.defective;

      cy.xpath(`(//tbody/tr/td[5]/div[1]//span)[${index + 1}]`).click();
      cy.xpath("((//p[text()='Amazon Fulfilled Quantity']/../div//span[text()='Total'])[2]/../../following-sibling::div)[1]//b").invoke('text').then(total => {
        total = total.replace(/[^0-9a-zA-Z. ]/g, '');
        softExpect(+total).to.equal(totalunFullfilled);
      });
      cy.xpath(`(//tbody/tr/td[2])[${index + 1}]`).click({ force: true });
    });
  });

});

