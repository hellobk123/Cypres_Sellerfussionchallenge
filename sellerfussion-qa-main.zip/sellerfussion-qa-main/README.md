# Open Terminal and enter npm install
# Then enter 'npm start' to run the scripts
# report will be available in cypress/reports folder
# Automation video will be present in cypress/videos folder
